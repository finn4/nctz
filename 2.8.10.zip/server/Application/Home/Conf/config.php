<?php 
return array(
	//'配置项'=>'配置值'
    'showdoc' => 'showdoc not install'
);